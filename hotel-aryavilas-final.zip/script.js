document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bookingForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Thank you for booking with Hotel Aryavilas! We will contact you soon.");
    form.reset();
  });
});
